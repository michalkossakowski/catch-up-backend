﻿namespace catch_up_backend.Enums
{
    public enum StateEnum
    {
        Active = 0,
        Archived = 5,
        Deleted = 10
    }
}
