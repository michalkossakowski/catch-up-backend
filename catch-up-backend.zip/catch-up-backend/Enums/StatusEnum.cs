﻿namespace catch_up_backend.Enums
{
    public enum StatusEnum
    {
        ToDo = 0,
        InProgress = 10,
        ToReview = 20,
        ReOpen = 30,
        Done = 40,
    }
}
