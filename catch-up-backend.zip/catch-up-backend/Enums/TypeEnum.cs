﻿namespace catch_up_backend.Enums
{
    public enum TypeEnum
    {
        Newbie,
        Mentor,
        Menager,
        Admin
    }
}
