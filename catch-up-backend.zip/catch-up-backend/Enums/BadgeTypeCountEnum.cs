﻿namespace catch_up_backend.Enums
{
    public enum BadgeTypeCountEnum
    {
        AssignNewbiesCount = 10,
        CheckedTasksCount = 20,
        CreatedTasksCount = 30,
        CreatedSchoolingsCount = 40
    }
}
