﻿namespace catch_up_backend.Enums
{
    public enum ResourceTypeEnum
    {
        Material = 10,
        Schooling = 20,
        Faq = 30,
        Task = 40
    }
}
