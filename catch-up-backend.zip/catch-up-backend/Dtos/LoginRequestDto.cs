﻿namespace catch_up_backend.Dtos
{
    public class LoginRequestDto{
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
