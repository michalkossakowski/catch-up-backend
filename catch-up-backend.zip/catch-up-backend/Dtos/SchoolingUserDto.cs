﻿using catch_up_backend.Enums;

namespace catch_up_backend.Dtos
{
    public class SchoolingUserDto
    {
        public Guid NewbieId { get; set; }
        public int SchoolingId { get; set; }
    }
}
