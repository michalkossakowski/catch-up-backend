﻿namespace catch_up_backend.Dtos
{
    public class RegisterFirebaseTokenRequest
    {
        public string FirebaseToken { get; set; }
        public string DeviceName { get; set; }
    }
}
