﻿namespace catch_up_backend.Dtos
{
    public class CompanyCityDto
    {
        public string CityName { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double RadiusKm { get; set; }
    }
}
