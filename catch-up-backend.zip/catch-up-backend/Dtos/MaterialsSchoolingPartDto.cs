﻿using catch_up_backend.Enums;

namespace catch_up_backend.Dtos
{
    public class MaterialsSchoolingPartDto
    {
        public int MaterialsId { get; set; }
        public int SchoolingPartId { get; set; }
    }
}
