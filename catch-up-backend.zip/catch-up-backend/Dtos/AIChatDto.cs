﻿namespace catch_up_backend.Dtos
{
    public class AIChatDto
    {
        public string Message { get; set; }
        public string AdditionalPromptPreferences { get; set; }
    }
}
